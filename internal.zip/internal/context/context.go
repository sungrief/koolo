package context

import (
	"log/slog"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/hectorgimenez/d2go/pkg/data"
	"github.com/hectorgimenez/d2go/pkg/data/area"
	"github.com/hectorgimenez/koolo/internal/config"
	"github.com/hectorgimenez/koolo/internal/event"
	"github.com/hectorgimenez/koolo/internal/game"
	"github.com/hectorgimenez/koolo/internal/health"
	"github.com/hectorgimenez/koolo/internal/pather"
)

var mu sync.Mutex
var botContexts = make(map[uint64]*Status)

type Priority int

type StopFunc func()

const (
	PriorityHigh       = 0
	PriorityNormal     = 1
	PriorityBackground = 5
	PriorityPause      = 10
	PriorityStop       = 100
)

type Status struct {
	*Context
	Priority Priority
}

type Context struct {
	Name               string
	ExecutionPriority  Priority
	CharacterCfg       *config.CharacterCfg
	Data               *game.Data
	EventListener      *event.Listener
	HID                *game.HID
	Logger             *slog.Logger
	Manager            *game.Manager
	GameReader         *game.MemoryReader
	MemoryInjector     *game.MemoryInjector
	PathFinder         *pather.PathFinder
	BeltManager        *health.BeltManager
	HealthManager      *health.Manager
	Char               Character
	LastBuffAt         time.Time
	ContextDebug       map[Priority]*Debug
	CurrentGame        *CurrentGameHelper
	SkillPointIndex    int // NEW FIELD: Tracks the next skill to consider from the character's SkillPoints() list
	ForceAttack        bool
	StopSupervisorFn   StopFunc
	CleanStopRequested bool
	RestartWithCharacter string
	PacketSender       *game.PacketSender
}

type Debug struct {
	LastAction string `json:"lastAction"`
	LastStep   string `json:"lastStep"`
}

type CurrentGameHelper struct {
	BlacklistedItems []data.Item
	PickedUpItems    map[int]int
	AreaCorrection   struct {
		Enabled      bool
		ExpectedArea area.ID
	}
	PickupItems                bool
	FailedToCreateGameAttempts int
	FailedMenuAttempts         int
	// When this is set, the supervisor will stop and the manager will start a new supervisor for the specified character.
	SwitchToCharacter string
	// Used to store the original character name when muling, so we can switch back.
	OriginalCharacter string
	CurrentMuleIndex  int
	ShouldCheckStash  bool
	StashFull         bool
}

func (ctx *Context) StopSupervisor() {
	if ctx.StopSupervisorFn != nil {
		ctx.Logger.Info("Game logic requested supervisor stop.", "source", "context")
		ctx.CleanStopRequested = true // SET THE FLAG
		ctx.StopSupervisorFn()
	} else {
		ctx.Logger.Warn("StopSupervisorFn is not set. Cannot stop supervisor from context.")
	}
}

func NewContext(name string) *Status {
	ctx := &Context{
		Name:              name,
		Data:              &game.Data{},
		ExecutionPriority: PriorityNormal,
		ContextDebug: map[Priority]*Debug{
			PriorityBackground: {},
			PriorityNormal:     {},
			PriorityHigh:       {},
			PriorityPause:      {},
			PriorityStop:       {},
		},
		CurrentGame:     NewGameHelper(),
		SkillPointIndex: 0,
		ForceAttack:     false,
	}
	botContexts[getGoroutineID()] = &Status{Priority: PriorityNormal, Context: ctx}

	return botContexts[getGoroutineID()]
}

func NewGameHelper() *CurrentGameHelper {
	return &CurrentGameHelper{
		PickupItems:                true,
		PickedUpItems:              make(map[int]int),
		BlacklistedItems:           []data.Item{},
		FailedToCreateGameAttempts: 0,
	}
}

func Get() *Status {
	mu.Lock()
	defer mu.Unlock()
	return botContexts[getGoroutineID()]
}

func (s *Status) SetLastAction(actionName string) {
	s.Context.ContextDebug[s.Priority].LastAction = actionName
}

func (s *Status) SetLastStep(stepName string) {
	s.Context.ContextDebug[s.Priority].LastStep = stepName
}

func getGoroutineID() uint64 {
	var buf [64]byte
	n := runtime.Stack(buf[:], false)
	stackTrace := string(buf[:n])
	fields := strings.Fields(stackTrace)
	id, _ := strconv.ParseUint(fields[1], 10, 64)

	return id
}

func (ctx *Context) RefreshGameData() {
	*ctx.Data = ctx.GameReader.GetData()
}

func (ctx *Context) RefreshInventory() {
	ctx.Data.Inventory = ctx.GameReader.GetInventory()
}

func (ctx *Context) Detach() {
	mu.Lock()
	defer mu.Unlock()
	delete(botContexts, getGoroutineID())
}

func (ctx *Context) AttachRoutine(priority Priority) {
	mu.Lock()
	defer mu.Unlock()
	botContexts[getGoroutineID()] = &Status{Priority: priority, Context: ctx}
}

func (ctx *Context) SwitchPriority(priority Priority) {
	ctx.ExecutionPriority = priority
}

func (ctx *Context) DisableItemPickup() {
	ctx.CurrentGame.PickupItems = false
}

func (ctx *Context) EnableItemPickup() {
	ctx.CurrentGame.PickupItems = true
}

func (s *Status) PauseIfNotPriority() {
	// This prevents bot from trying to move when loading screen is shown.
	if s.Data.OpenMenus.LoadingScreen {
		time.Sleep(time.Millisecond * 5)
	}

	for s.Priority != s.ExecutionPriority {
		if s.ExecutionPriority == PriorityStop {
			panic("Bot is stopped")
		}

		time.Sleep(time.Millisecond * 10)
	}
}
func (ctx *Context) WaitForGameToLoad() {
	for ctx.Data.OpenMenus.LoadingScreen {
		time.Sleep(100 * time.Millisecond)
		ctx.RefreshGameData()
	}
	// Add a small buffer to ensure everything is fully loaded
	time.Sleep(300 * time.Millisecond)
}

func (ctx *Context) Cleanup() {
	ctx.Logger.Debug("Resetting blacklisted items")

	// Remove all items from the blacklisted items list
	ctx.CurrentGame.BlacklistedItems = []data.Item{}

	// Remove all items from the picked up items map if it exceeds 200 items
	if len(ctx.CurrentGame.PickedUpItems) > 200 {
		ctx.Logger.Debug("Resetting picked up items map due to exceeding 200 items")
		ctx.CurrentGame.PickedUpItems = make(map[int]int)
	}
	// Reset counters on cleanup for a new session
	ctx.CurrentGame.FailedToCreateGameAttempts = 0
	ctx.CurrentGame.FailedMenuAttempts = 0 // Also reset this on cleanup
}
